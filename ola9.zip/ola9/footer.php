<?php
/**
* ملف تمبلت الفوتر  
* أي كل ما هو موجود بعد الوسم main
 * @package ola1
 * @subpackage olatheme
 */
?>
<footer>
<div class="container">
 <!-- 1.footer nav -->
<div class="footer-nav">
		<section>
			<?php
			if ( has_nav_menu( 'footer' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'items_wrap'     => '<ul class="inline">%3$s</ul>',
						'fallback_cb'    => false,
						'depth'          =>1,
					)
				);
			}
			?>
		</section>
	</div>
</footer>

 <!-- 2.copyright -->
<div class="site-info"> 
	<p class="site-info">
	<?php printf( '%s.جميع الحقوق محفوظة&copy; %s', get_bloginfo('name'), date( 'Y' ) ); ?>
	</p>
</div>

</div> 
<!-- 3.footer hook -->
<?php echo wp_footer(); ?>
</body>
</html>
