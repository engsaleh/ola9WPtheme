<?php
/**
 * ملف تمبلت خاص بصفحة حولنا    
 * Template Name: templateAboutPage
 */
?>
<?php get_header(); ?>
<?php while( have_posts() ): ?>
    <?php the_post(); ?>
    <main class="page">
     <h1 class="page-title"><?php _e( 'مرحبًا بك في صفحة حولنا', 'olatheme' ); ?></h1>
       <section class="content"
       class="featured-image">
        <?php if ( has_post_thumbnail() ) :
         $featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'large' ); ?>
         <img class="featured-image" src="<?php echo $featured_image[0]; ?>" alt='' />
         <?php endif; ?>
        </div>
		<?php the_content() ?>
		<?php
		 if ( comments_open() || get_comments_number() ) { ?>
         <h2>
		 <?php echo get_comments_number(); ?>
		 <?php echo get_comments_number() === 1 ? _e( 'تعليق', 'olatheme' ) : _e( 'تعليقات', 'olatheme' ); ?>
        </h2>
         <?php comments_template();}?>
        </section>
    </main>
<?php endwhile; ?> 
<?php get_footer(); ?>
