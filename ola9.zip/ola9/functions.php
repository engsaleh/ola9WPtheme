<?php

function ola_new_excerpt_more( $more ) {
    return '';
}
add_filter('excerpt_more', 'ola_new_excerpt_more');


// دعم ميزة تخصيص اللوجو في القالب
add_theme_support( 'custom-logo', array(
    'height'      => 100,
    'width'       => 100,
    'flex-height' => true,
    'flex-width'  => true,
) );

// تسجيل قائمة تنقل رئيسية وقائمة تنقل في الفوتر في القالب
function register_my_menus() {
	register_nav_menus([
	   'primary' => __( 'القائمة الرئيسية' ),
	   'footer'  => __( 'قائمة الفوتر' ),
	 ]);
   }
	add_action( 'init', 'register_my_menus' );



// دعم الصورة المميزة للقالب
add_theme_support( 'post-thumbnails' );


//إضافة عنصر قائمة مخصص في لوحة التحكم
function add_theme_menu_item()
 {
	add_menu_page("Ola Theme page",
 	              "Ola Theme page", 
 	              "manage_options", 
 	              "ola-theme-page",
  	              "my_admin_page_contents", 
 	              null, 
 	              62);
 }

add_action("admin_menu", "add_theme_menu_item");

//صفحة مخصصة للقالب في لوحة التحكم
function my_admin_page_contents()
{
    ?>
	    <div class="wrap">
	    <h1>Ola Theme page </h1>
			<h2>
				هذا القالب مطور لأغراض تعليمة ضمن سلسلة تعلم تطوير القوالب المقدمة من ووردبريس بالعربية
				<br>
			</h2>
	    <form method="post" action="options.php"  enctype="multipart/form-data" >
	        <?php
	            settings_fields("section");
	            do_settings_sections("theme-options");      
	            submit_button(); 
	        ?>          
	    </form>
		</div>
	<?php
}
function logo_display()
{
?>
        <input type="file" name="logo" /> 
       <h2> <?php echo get_option('logo'); ?> </h2>
   <?php
}

function handle_logo_upload($option)
{
  if(!empty($_FILES["logo"]["tmp_name"]))
  {
    $urls = wp_handle_upload($_FILES["logo"], array('test_form' => FALSE));
    $temp = $urls["url"];
    return $temp;  
  }
 
  return $option;
}
function display_theme_page_fields()
{
    add_settings_section("section", "إعدادات القالب", null, "theme-options");
    add_settings_field("logo", "لوجو الموقع", "logo_display", "theme-options", "section");  
    register_setting("section", "logo", "handle_logo_upload");
}
add_action("admin_init", "display_theme_page_fields");



