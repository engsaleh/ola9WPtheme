<?php
/**
* ملف تمبلت الهيدر  
* أي كل ما هو موجود فوق الوسم main
 * @package ola1
 * @subpackage olatheme
 */
?>

<!DOCTYPE html>

<html  class="no-js" lang="<?php bloginfo("language"); ?>">
<head>

   <!--- Basic Page Needs -->
	<title>
     <?php bloginfo("name");  ?>
    </title>

   
	<!-- Meta -->
	<!-- mobile specific meta  -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
	<meta name="description" content="Blog wordpress theme">
	<meta name="author" content="OLA SALEH">
	<meta charset="utf-8">
	<!-- CSS  -->
	<link rel="stylesheet" href="<?php echo  get_template_directory_uri();?>/style.css">
	<link rel="shortcut icon" href="images/logo.png" sizes="100x100" >

<!--  Header hook -->
<?php wp_head(); ?>
</head>

<body>

	<header class="site-header">
	<div class= "wrapper site-header__wrapper">
		 <!-- Website logo -->
		<div class= 'logo'>
		 <a  class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home">
       <img src="<?php echo get_option('logo');; ?>" alt="Logo" width="150" height="150" />
    </a>
	</div>

	 <nav class="header-menu-init-xl">
	   <?php 
      if ( has_nav_menu( 'primary' ) ) { 
      wp_nav_menu( array(
      'theme_location' => 'primary',
      'items_wrap'     => '<ul>%3$s</ul>',
       'menu_class' => 'my-navigation',
        'fallback_cb'    => false,
        'depth'=> 1,)
          );
        }  ?>
		</nav>	
		</div>


	 <!-- search  Form -->
	<section class="search">

	<?php  get_search_form ();  ?>

	</section>

	</header>
	