<?php
/**
 *ملف التمبلت الأساسي 
 * @package ola1
 * @subpackage olatheme
 */
?>

<?php get_header(); ?>

<main>
	<section class="featured">
	<p class="featured">
		<?php  echo __( 'هذا القالب مطور لأغراض تعليمة 
		 ضمن سلسلة  تعلم تطوير القوالب المقدمة من ','olatheme'); ?>
		<a href="https://www.wpar.net//"> <?php echo __( 'ووردبريس بالعربية', 'olatheme'); ?>  </a></p>

	</section>

	<h2 class="text-center"><?php _e( 'أحدث المقالات' ); ?></h2>

	<section class="articles">
		<?php 
if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		?>
		<article>
			<?php if ( has_post_thumbnail() ) { ?>
				<div class="thumb" style="background-image: url(<?php the_post_thumbnail_url(); ?>);"></div>
				<?php } else{  ?>
				<div class="thumb" style="background-image: url(<?php bloginfo('template_directory'); ?>/images/default.png");"></div> 
				<?php
				 }
				?>
			<?php the_category('،  '); ?>
			<a href="<?php the_permalink(); ?>">
				<?php the_title( '<h3>', '</h3>' ); ?>
			</a>
			<div class="summary"><?php the_excerpt(); ?></div>
			<a class="btn btn-link" href="<?php the_permalink(); ?>"><?php _e( 'قراءة المزيد','olatheme' ); ?></a>
		</article>
		<?php
	}
} else {
	echo _e( 'لا توجد مقالات بعد' ,'olatheme');
}
		 ?>
	</section>
	<nav class="pagination">
	<?php echo previous_posts_link( __( '&lt; مقالات أحدث','olatheme' ) ); ?>
	<?php echo next_posts_link( __( 'مقالات أقدم &gt;' ,'olatheme') ); ?>
</nav>
</main>

<?php get_footer(); ?>
