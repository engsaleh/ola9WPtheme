<?php
/**
 * ملف القالب المخصص لعرض فورم البحث في القالب
 *
 * @package ola1
 * @subpackage olatheme
 */
?>

<form
		role="search"
		class="search-form <?php echo get_search_query() ? 'active' : ''; ?>"
		id="search-form"
		method="get"
		action="<?php echo esc_url( home_url( '/' ) ); ?>">
		<input type="search" value="<?php echo get_search_query(); ?>" name="s"
         placeholder="<?php _e('عم تبحث؟&hellip;', 'olatheme'); ?>" required />
		<button type="submit" class="sbtn"><?php _e( 'ابحث', 'olatheme' ); ?></button>
	</form>
