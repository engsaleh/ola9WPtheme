<?php
/**
* ملف تمبلت صفحة الخطأ 404  
* تصل لهذه الصفحة في حال الانتقال لرابط غير موجود في الموقع
 * @package ola1
 * @subpackage olatheme
 */
?>



<?php get_header(); ?>

<main class="page404">
	<h1 class="text-center"><?php _e( 'هناك خطب ما!&hellip;', 'olatheme' ); ?></h1>
	<section class="content">

    	 <div  class="page404">
		 <img  class="page404"  src="<?php echo get_stylesheet_directory_uri(); ?>/images/bg.jpg" />
		 </div>
		 

		<h2><?php _e( 'للأسف لا يمكننا أن نعثر على الصفحة التي تريد عرضها.', 'olatheme' ); ?></h2>
		<p>
			<?php _e( 'تأكد من أنك أدخلت الرابط المطلوب بالشكل الصحيح.', 'thunderblog' ); ?>
		</p>
		<p>
			<?php _e( 'ما رأيك أن تبحث في صندوق البحث عن المحتوى الذي تريده.</p>', 'thunderblog' ); ?>
		</p>

	</section>
</main>

<?php get_footer(); ?>
