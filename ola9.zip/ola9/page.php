<?php
/**
* ملف تمبلت الصقحات الثابتة   
* في الموقع pages
 * @package ola1
 * @subpackage olatheme
 */
?>
<?php get_header(); ?>
<main class="page">
	<h1 class="text-center"><?php the_title() ?></h1>
	<section class="content">
	<?php the_content() ?>
	<?php
	if ( comments_open() || get_comments_number() ) { ?>
	<h2> <?php echo get_comments_number(); ?>
	<?php echo get_comments_number() === 1 ? _e( 'تعليق', 'olatheme' ) : _e( 'تعليقات', 'olatheme' ); ?></h2>
	<?php comments_template();
	}
?>
</section>
</main>
<?php get_footer(); ?>
