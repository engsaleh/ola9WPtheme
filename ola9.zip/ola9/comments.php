
<?php
/**
* ملف تمبلت التعليقات  
* يعرض فورم التعليق والتعليقات أسفل كل مقال
 * @package ola1
 * @subpackage olatheme
 */



if ( post_password_required() ) {
	return;
}
//عرض لائحة التعليقات
if ( have_comments() ) :
	echo wp_list_comments(
		array(
			'style'       => 'div',
			'avatar_size' => 65,
			'short_ping'  => true,)
	);
	
	if ( ! comments_open() ) :
		?>
		<p class="no-comments"><?php _e( 'التعليقات مغلقة لهذا المقال.', 'olatheme' ); ?></p>
		<?php
	endif;
endif;

//عرض فورم التعليقات
echo comment_form(
	array(
		'submit_button' => '<button name="%1$s" type="submit" id="%2$s" class="btn %3$s">%4$s</button>',
	)
);
?>
