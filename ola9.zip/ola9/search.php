
<?php
/**
* ملف تمبلت صفحة نتائج البحث  
 * @package ola1
 * @subpackage olatheme
 */
?>

<?php get_header(); ?>

<main>
	<h2 class="text-center  page-title">
	<?php
			printf(
				esc_html( '%d نتيجة للبحث عن',  (int) $wp_query->found_posts, 'olatheme'),
				(int) $wp_query->found_posts);
			?>
		&quot;<?php echo get_search_query() ?>&quot;
	</h2>


	<section class="search-results">
		<?php 
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				?>
				<div class="search-results">
					<a href="<?php the_permalink(); ?>">
						<?php the_title( '<h3>', '</h3>' ); ?>
					</a>
					<div class="summary"><?php the_excerpt(); ?></div>
					<a class="btn btn-link" href="<?php the_permalink(); ?>"><?php _e( 'اقرأ المزيد', 'olatheme' ); ?></a>
			</div>
				<?php
			}
		} else {?>
			
			<h2 class="text-center  page-title">
			<?php _e( 'لا توجد نتائج لما تبحث عنه.', 'olatheme' ); ?>
			</h2>
			<?php } ?>
		 
	</section>
	<nav class="pagination">
	<?php echo previous_posts_link( __( '&laquo; نتائج أحدث', 'olatheme' ) ); ?>
	<?php echo next_posts_link( __( 'نتائج أقدم &raquo;', 'olatheme' ) ); ?>
</nav>

</main>

<?php get_footer(); ?>
